import { REASONS } from '@shared/events.js';
import { STATUS_UI } from './status.js';

const reasonLabel = (id) => REASONS.find((r) => r.id === id)?.label;

// hideNames: for a projector, show only colored dots so nobody is singled out in front of the class.
export default function StudentGrid({ students = [], hideNames = false }) {
  if (!students.length) return <p className="text-sm text-slate-500">Nobody has joined yet. Share the code.</p>;

  if (hideNames) {
    return (
      <ul className="flex flex-wrap gap-2">
        {students.map((s) => (
          <li key={s.id} title={STATUS_UI[s.status].label}
              className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold ring-1 ${STATUS_UI[s.status].chip} ${s.connected ? '' : 'opacity-50'}`}>
            {STATUS_UI[s.status].symbol}
          </li>
        ))}
      </ul>
    );
  }

  return (
    <ul className="flex flex-wrap gap-2">
      {students.map((s) => {
        const ui = STATUS_UI[s.status];
        const why = reasonLabel(s.reason);
        return (
          <li key={s.id} title={`${s.name}: ${ui.label}${why ? ` (${why})` : ''}`}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-sm font-medium ring-1 ${ui.chip} ${s.connected ? '' : 'opacity-50'}`}>
            <span aria-hidden>{ui.symbol}</span>
            <span dir="auto">{s.name}</span>
            {why && <span className="text-xs font-normal opacity-75">· {why}</span>}
            {s.focusFlags > 0 && <span title="Left the page" className="rounded bg-slate-800 px-1 text-xs text-white">🔒 {s.focusFlags}</span>}
          </li>
        );
      })}
    </ul>
  );
}
